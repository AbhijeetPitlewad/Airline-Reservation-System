export class user{
	userEmail:string="" ;
	userTitle:string=""  ;
	userFirstName:string="" ;
    userLastName:string="" ;
    userDob:string="" ;
    userPassword:string="" ;
    userPhone:string="" ;
    que:string="" ;
    ans:string="" ;
}