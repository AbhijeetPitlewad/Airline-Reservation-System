export class admin{
	adminUserName:string="" ;
	adminPassword:string=""  ;
	adminName:string="" ;
}